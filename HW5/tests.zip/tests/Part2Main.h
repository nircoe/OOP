#include <iostream>
#include "staff/Part2Examples.h"
#include "my/MyTest.h"
#include "partner/PartnerPartTwoMain.h"

void part2Main() {
    cout<<"part2Main"<<endl;
    MyTest().test();
    Part2Examples().mainPart2Examples();
    PartnerPartTwoMain().partnerPartTwoMain();
}
